using UnityEngine;
using System.Collections;

public static class GFNearestLegacy {

	public static Vector3 NearestFaceGL (this GFRectGrid grid, Vector3 world, GFGrid.GridPlane plane) {
		Vector3 planeVec = Vector3.zero;
		switch (plane) {
		case (GFGrid.GridPlane.XY):
			planeVec = Vector3.forward;
			break;
		case GFGrid.GridPlane.XZ:
			planeVec = Vector3.up;
			break;
		case GFGrid.GridPlane.YZ:
			planeVec = Vector3.right;
			break;
		}
		return grid.NearestFaceW (world, plane) - 0.5f * Vector3.one + 0.5f * planeVec;
	}

	public static Vector3 NearestBoxGL (this GFRectGrid grid, Vector3 world) {
		return grid.NearestBoxG (world) - 0.5f * Vector3.one;
	}
}

using UnityEngine;
using System.Collections;

// Contains the old vertex matrix methods that were removed in version 1.3.1; use this for backwards compatibility in your old scripts
// Personally though, I would recommend writing your own methods tailore specifically to your needs.
public static class GFVertexMatrixLegacy {

	// this is the starting point, the methods to call through script:
	#region Abstract
	// let's have some handy overloads first
	#region Overloads
	// a vector for size
	public static Vector3[,,] BuildVertexMatrix (this GFGrid grid, Vector3 matrixSize) {
		return BuildVertexMatrix (grid, matrixSize.x, matrixSize.y, matrixSize.z);
	}
	// three individual floats for size (instead of int)
	public static Vector3[,,] BuildVertexMatrix (this GFGrid grid, float width, float height, float depth) {
		return BuildVertexMatrix (grid, Mathf.RoundToInt (width), Mathf.RoundToInt (height), Mathf.RoundToInt (depth));
	}
	// an array of int for size
	public static Vector3[,,] BuildVertexMatrix (this GFGrid grid, int[] size) {
		return BuildVertexMatrix (grid, size [0], size [1], size [2]);
	}
	#endregion
	// call this method as if it were part of the grid API
	public static Vector3[,,] BuildVertexMatrix (this GFGrid grid, uint width, uint height, uint depth) {
		// we will decide the exact implementation based on the specific type of grid
		System.Type gridType = grid.GetType ();
		// store the vertices in here
		Vector3[,,] vertexMatrix = new Vector3[1,1,1];
		// now pick the proper implementation based on the type
		if (gridType == typeof(GFRectGrid)) {
			vertexMatrix =  BuildVertexMatrixRect ((GFRectGrid)grid, width, height, depth);
		} else if (gridType == typeof(GFHexGrid)) {
			vertexMatrix = BuildVertexMatrixHex ((GFHexGrid)grid, width, height, depth);
		} else if (gridType == typeof(GFPolarGrid)) {
			vertexMatrix = BuildVertexMatrixPolar ((GFPolarGrid)grid, width, height, depth);
		} else { // for future grids
			vertexMatrix = new Vector3[1, 1, 1];
			Debug.LogWarning ("Vertex matrix methods for grid class " + gridType.ToString() + " not defined, returning empty array.");
		}

		return vertexMatrix;
	}

	public static Vector3 ReadVertxMatrix (this GFGrid grid, int x, int y, int z, Vector3[,,] vertexMatrix, bool warning = false) {
		System.Type gridType = grid.GetType ();
		Vector3 vertex;

		if (gridType == typeof(GFRectGrid)) {
			vertex =  ReadVertexMatrixRect((GFRectGrid)grid, x, y, z, vertexMatrix, warning);
		} else if (gridType == typeof(GFHexGrid)) {
			vertex = ReadVertexMatrixHex((GFHexGrid)grid, x, y, z, vertexMatrix, warning);
		} else if (gridType == typeof(GFPolarGrid)) {
			vertex = ReadVertexMatrixPolar((GFPolarGrid)grid, x, y, z, vertexMatrix, warning);
		} else { // for future grids
			vertex = Vector3.zero;
			Debug.LogWarning ("Vertex matrix methods for grid class " + gridType.ToString() + " not defined, returning empty array.");
		}

		return vertex;
	}

	public static void DrawVertices (this GFGrid grid, Vector3[,,] vertexMatrix, Color vertexColor, bool drawOnPlay = false) {
		//do not draw vertices when playing, this is a performance hog
		if(Application.isPlaying && !drawOnPlay)
			return;

		Gizmos.color = vertexColor;

		for(int i=0;  i<= vertexMatrix.GetUpperBound(0); i++){
			for(int j=0;  j<= vertexMatrix.GetUpperBound(1); j++){
				for(int k=0;  k<= vertexMatrix.GetUpperBound(2); k++){
					DrawSphere(vertexMatrix[i,j,k]);
				}
			}
		}
	}

	private static void DrawSphere (Vector3 pos, float rad = 0.3f){
		Gizmos.DrawSphere(pos, rad);
	}
	#endregion

	#region Rectangular
	//NOTE ABOUT MATRIX ORDER: The matrix starts in the topright most backwards corner, the first component
	//	represents the width, from right to left, the second one the height from top to bottom, the third
	//	the depth from back to front
	private static Vector3[,,] BuildVertexMatrixRect (this GFRectGrid grid, uint width, uint height, uint depth) {
		Vector3 iterationVector = new Vector3(width, height, depth);
		Vector3[,,] vertexMatrix = new Vector3[2 * width + 1, 2 * height + 1, 2 * depth + 1];

		for(int i = 0; i <= 2 * width; i++){
			for(int j = 0; j <=  2 * height; j++){
				for(int k = 0; k <= 2 * depth; k++){
					vertexMatrix[i,j,k] = grid.GridToWorld(iterationVector - new Vector3(i,j, k));
				}
			}
		}
		//		Debug.Log("Matrix size: " + vertexMatrix.GetUpperBound(0) +"/"+ vertexMatrix.GetUpperBound(1) +"/"+ vertexMatrix.GetUpperBound(2));

		return vertexMatrix;
	}

	// return an entry from the vertex matrix in a cartesian fashion (central vertex is (0,0,0), first component is the x-axis, second one the y-axis,
	// third one the z-axis
	private static Vector3 ReadVertexMatrixRect (this GFRectGrid grid, int x, int y, int z, Vector3[,,] vertexMatrix, bool warning = false) {
		if(Mathf.Abs(x) > vertexMatrix.GetUpperBound(0) / 2 || Mathf.Abs(y) > vertexMatrix.GetUpperBound(1) / 2 || Mathf.Abs(z) > vertexMatrix.GetUpperBound(2) / 2){
			if(warning)
				Debug.LogWarning("coordinates too large for this matrix, will default to " + Vector3.zero);
			return vertexMatrix[(vertexMatrix.GetUpperBound(0)/2), (vertexMatrix.GetUpperBound(1)/2), (vertexMatrix.GetUpperBound(2)/2)];
		}
		return vertexMatrix[(vertexMatrix.GetUpperBound(0)/2) - x, (vertexMatrix.GetUpperBound(1)/2) - y, (vertexMatrix.GetUpperBound(2)/2) - z];
	}
	#endregion

	#region Hexagonal
	private static Vector3[,,] BuildVertexMatrixHex (this GFHexGrid grid, uint width, uint height, uint depth) {
		uint[] matrixSize = new uint[3]{width, height, depth};

		Vector3[,,] vertexMatrix = new Vector3[2*matrixSize[0]+1, 4*matrixSize[1]+2, 2*matrixSize[2]+1];
		int yIterator = 0;

		for(int z = 0; z <= 2 * matrixSize[2]; z++){
			for(int x = 0; x <= 2 * matrixSize[0]; x++){
				for(int y = 0; y < 2 * matrixSize[1]; y++){
					bool shifted = matrixSize[0] % 2 == 1 ? x % 2 == 0 : x % 2 == 1;
					Vector3 hex = grid.GridToWorld(new Vector3(-matrixSize[0], -matrixSize[1], -matrixSize[2]) + new Vector3(x, y, z));
					//	Debug.Log(hex);
					//	Gizmos.DrawSphere(hex, 0.4f);
					if(y == 0 && shifted){
						Vector3 leftHex = grid.GridToWorld(new Vector3(-matrixSize[0], -matrixSize[1], -matrixSize[2]) + new Vector3(x-1, y, z));
						vertexMatrix[x, yIterator, z] = leftHex + grid.VertexToDirection(GFHexGrid.HexDirection.SE);
						yIterator++;
					}
					vertexMatrix[x, yIterator, z] = hex + grid.VertexToDirection(GFHexGrid.HexDirection.SW);
					yIterator++;
					vertexMatrix[x, yIterator, z] = hex + grid.VertexToDirection(GFHexGrid.HexDirection.W);
					yIterator++;
					if(y == 2 * matrixSize[1] - 1){
						vertexMatrix[x, yIterator, z] = hex + grid.VertexToDirection(GFHexGrid.HexDirection.NW);
						yIterator++;
					}
					if(y == 2 * matrixSize[1] - 1 && !shifted){
						Vector3 leftHex = grid.GridToWorld(new Vector3(-matrixSize[0], -matrixSize[1], -matrixSize[2]) + new Vector3(x-1, y, z));
						vertexMatrix[x, yIterator, z] = leftHex + grid.VertexToDirection(GFHexGrid.HexDirection.NE);
						yIterator++;
					}
				}
				yIterator = 0;
			}
		}

		return vertexMatrix;
	}

	private static Vector3 ReadVertexMatrixHex (this GFHexGrid grid, int x, int y, int z, Vector3[,,] vertexMatrix, bool warning = false) {
		if(Mathf.Abs(x)>vertexMatrix.GetUpperBound(0)/2 || Mathf.Abs(y) >vertexMatrix.GetUpperBound(1)/2 || Mathf.Abs(z) >vertexMatrix.GetUpperBound(2)/2){
			if(warning)
				Debug.LogWarning("coordinates too large for this matrix, will default to " + Vector3.zero);
			return vertexMatrix[(vertexMatrix.GetUpperBound(0)/2), (vertexMatrix.GetUpperBound(1)/2), (vertexMatrix.GetUpperBound(2)/2)];
		}
		return vertexMatrix[(vertexMatrix.GetUpperBound(0)/2) + x, (vertexMatrix.GetUpperBound(1)/2) + y, (vertexMatrix.GetUpperBound(2)/2) + z];
	}
	#endregion

	#region Polar
	private static Vector3[,,] BuildVertexMatrixPolar (this GFPolarGrid grid, uint width, uint height, uint depth) {
		Vector3[,,] vertexMatrix = new Vector3[width, Mathf.RoundToInt(Mathf.Min(height, grid.sectors)), 2 * depth + 1];

		// fill the matrix
		for (int k = 0; k < vertexMatrix.GetLength(2); k++) {
			for (int i = 1; i <= vertexMatrix.GetLength(0); i++) {
				for (int j = 0; j < vertexMatrix.GetLength(1); j++) {
					vertexMatrix[i-1,j,k] = grid.GridToWorld(new Vector3(i, j, k - Mathf.RoundToInt(width) ));
				}
			}
		}
		return vertexMatrix;
	}

	private static Vector3 ReadVertexMatrixPolar (this GFPolarGrid grid, int i, int j, int k, Vector3[,,] vertexMatrix, bool warning = false) {
		return Vector3.zero;
	}
	#endregion
}
